import pandas as pd
from smartspoon.recommender import TasteRecommender

# Load data
df = pd.read_csv('data/taste_profiles.csv')
recommender = TasteRecommender(df)
recommender.train()

# Simulated user input
user_taste = [3, 2, 1, 5, 1]  # Spicy, Sweet, Sour, Salty, Bitter
recommendations = recommender.recommend(user_taste)

print("Top Recommendations for You:")
for dish in recommendations:
    print("-", dish)
