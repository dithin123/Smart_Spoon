import pandas as pd
from sklearn.cluster import KMeans

class TasteRecommender:
    def __init__(self, df):
        self.df = df
        self.model = KMeans(n_clusters=3)
        
    def train(self):
        X = self.df[['spicy', 'sweet', 'sour', 'salty', 'bitter']]
        self.model.fit(X)
        self.df['cluster'] = self.model.labels_

    def recommend(self, taste_vector):
        cluster = self.model.predict([taste_vector])[0]
        recs = self.df[self.df['cluster'] == cluster]['favorite_dish'].unique()
        return recs[:3]
