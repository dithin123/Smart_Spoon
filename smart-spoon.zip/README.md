# Smart Spoon - Personalized Taste Profiles

**Smart Spoon** is a machine learning project that recommends food dishes to users based on their personalized taste preferences. It uses K-Means clustering and collaborative filtering for flavor profiling.

## Features
- Input: User taste data (spicy, sweet, sour, salty, bitter)
- Clustering of users with similar taste profiles
- Meal recommendations based on closest cluster

## Tech Stack
- Python
- Scikit-learn
- Pandas
- Streamlit (optional for frontend)

## How to Run

1. Clone the repo:
```bash
git clone https://github.com/yourusername/smart-spoon.git
cd smart-spoon
```

2. Install requirements:
```bash
pip install -r requirements.txt
```

3. Run the app:
```bash
python app.py
```

## Sample Dataset
`taste_profiles.csv` contains mock user taste preferences and rated dishes.

## Project Structure
- `notebook/`: Jupyter notebook for data analysis
- `smartspoon/`: Core ML logic
- `app.py`: Entry point (CLI or web app)
